import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york': 'new_york_city.csv',
              'washington': 'washington.csv' 
            }

month_options = ['all','january', 'february', 'march', 'april', 'may', 'june']

day_options = ['all','monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']

def format_seconds(total_seconds):
    days = total_seconds // 86400
    remainder = total_seconds % 86400
    hours = remainder // 3600
    remainder %= 3600
    minutes = remainder // 60
    seconds = remainder % 60
    return f"{int(days)} Days, {int(hours)} Hours, {int(minutes)} Minutes, {int(seconds)} Seconds"

def get_valid_input(message, valid_values):
    while True:
        value = input(message).strip().lower()
        if value in valid_values:
            print(f"Selected -> {value.title()}\n")
            return value
        print("Invalid input. Please try again.\n")

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Welcome to the US Bikeshare Data Explorer!')
    # get user input for city (chicago, new york city, washington). 
    city = get_valid_input(
        "Choose a city (Chicago, New York, Washington):\n",
        CITY_DATA.keys() )

    # get user input for month (all, january, february, ... , june)
    month = get_valid_input(
        "Choose a month (All, January, February, March, April, May, June):\n",
        month_options )

    # get user input for day of week (all, monday, tuesday, ... sunday)
    day = get_valid_input(
        "Choose a day (All, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday):\n",
        day_options )
    
    print("\nYou have selected:")
    print(f"City  -> {city.title()}")
    print(f"Month -> {month.title()}")
    print(f"Day   -> {day.title()}")

    confirm = input("\nProceed with these filters? (yes/no): ").lower()
    if confirm != 'yes':
        print("\nRestarting filter selection...\n")
        return get_filters()

    print('\n')
    print('*'*100)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    df = pd.read_csv(CITY_DATA[city])
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    df['month_num'] = df['Start Time'].dt.month
    df['weekday'] = df['Start Time'].dt.day_name()

    if month != 'all':
        df = df[df['month_num'] == month_options.index(month)]

    if day != 'all':
        df = df[df['weekday'] == day.title()]

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""
    print("\nTime Statistics")
    print('Calculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    common_month = month_options[df['month_num'].mode()[0]]
    print(f"Most Common Month -> {common_month.title()}")

    # Display the most common day of week
    common_day = df['weekday'].mode()[0]
    print(f"Most Common Day -> {common_day}")

    # display the most common start hour
    common_hour = df['Start Time'].dt.hour.mode()[0]
    print(f"Most Common Start Hour -> {common_hour}")

    print("\nCompleted in %s seconds." % (time.time() - start_time))
    print('*'*100)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""
    print("\nStation Statistics")
    print('Calculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # Display most commonly used start station
    print("Most Popular Start Station -> ", df['Start Station'].mode()[0])

    # display most commonly used end station
    print("Most Popular End Station -> ", df['End Station'].mode()[0])

    # display most frequent combination of start station and end station trip
    trip_pair = df.groupby(['Start Station', 'End Station']).size().idxmax()
    print(f"Most Frequent Trip (Start and End Stations): {trip_pair[0]} → {trip_pair[1]}")


    print("\nCompleted in %s seconds." % (time.time() - start_time))
    print('*'*100)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""
    print("\nTrip Duration Statistics")
    print('Calculating Trip Duration...\n')
    start_time = time.time()

    # Display total travel time
    # display mean travel time
    if 'Trip Duration' in df:
        total_time = df['Trip Duration'].sum()
        avg_time = df['Trip Duration'].mean()

        print("Total Duration -> ", format_seconds(total_time))
        print("Average Duration -> ", format_seconds(avg_time))
    else:
        print("Trip Duration data not available.")

    print("\nCompleted in %s seconds." % (time.time() - start_time))
    print('*'*100)


def user_stats(df):
    """Displays statistics on bikeshare users."""
    print("\nUser Statistics")
    print('Calculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    if 'User Type' in df:
        print("\nUser Types:")
        subscriber_count = (df['User Type'] == 'Subscriber').sum()
        customer_count = (df['User Type'] == 'Customer').sum()
        dependent_count = (df['User Type'] == 'Dependent').sum()
        most_common_user_type = df['User Type'].mode()[0]
        print("Subscriber -> ", subscriber_count)
        print("Customer -> ", customer_count)
        print("Dependent -> ", dependent_count)
        print("Most Common User Type -> ", most_common_user_type)
    # Display counts of gender
    if 'Gender' in df:
        print("\nGender Distribution:")
        male_count = (df['Gender'] == 'Male').sum()
        female_count = (df['Gender'] == 'Female').sum()
        print("Male Users -> ", male_count)
        print("Female Users -> ", female_count)
        most_common_gender = df['Gender'].mode()[0]
        print("Most Common Gender -> ", most_common_gender)
    # Display earliest, most recent, and most common year of birth
    if 'Birth Year' in df:
        print("\nBirth Year Stats:")
        print("Earliest -> ", int(df['Birth Year'].min()))
        print("Latest -> ", int(df['Birth Year'].max()))
        print("Most Common -> ", int(df['Birth Year'].mode()[0]))

    print("\nCompleted in %s seconds." % (time.time() - start_time))
    print('*'*100)

def show_raw_data(df):
    index = 0
    choice = input("\nWould you like to view individual trip data (5 rows at a time)? yes/no: ").lower()

    while choice == 'yes':
        print(df.iloc[index:index + 5])
        index += 5
        choice = input("\nView 5 more rows? yes/no: ").lower()


def main():
    while True:
        city, month, day = get_filters()

        df = load_data(city, month, day)

        if df.empty:
            print("\n⚠ No data available for selected filters.")
            restart = input("\nTry again? yes/no: ").lower()
            if restart != 'yes':
                break
            else:
                continue

        print("\nRunning time analysis...")
        time_stats(df)

        print("\nRunning station analysis...")
        station_stats(df)

        print("\nRunning trip duration analysis...")
        trip_duration_stats(df)

        print("\nRunning user statistics analysis...")
        user_stats(df)

        show_raw_data(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            print("\nThank you for using the Bikeshare Data Explorer. Goodbye!")
            break


if __name__ == "__main__":
	main()
